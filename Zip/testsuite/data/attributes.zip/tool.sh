#!/bin/sh
echo tool
